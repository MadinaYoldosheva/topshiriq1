'use strict'
// const [first, ...otherValues] = ['Madina', 'Mohinur', 'Husniya', 'Charos'];
// console.log(first);
// console.log(otherValues); 


// const ismlar=['Madina', 'Mohinur', 'Husniya', 'Charos'];
// const [ism1,ism2]=ismlar
// console.log(ism1,ism2);

// const ismlar=['Madina', 'Mohinur'];
// const ismlar2=[...ismlar,'Husniya', 'Charos']
// console.log(ismlar2);

// console.log('Madina' || 'Husniya'); 
// console.log('Madina' && 'Husniya'); 

// const myMap = new Map();
// myMap.set('firstname', 'Madina');
// myMap.set('secondname', 'Husniya');
// myMap.set('thirdname', 'Mohinur');
// console.log(myMap.get('secondname'));

// const mySet = new Set();
// mySet.add(1);
// mySet.add(2); 
// mySet.add(3); 
// mySet.add(48); 
// console.log(mySet);

// ism();
// function ism() {
// console.log('Madina');
// }

// const subects = ['math', 'physics'];
// const subects1 = subects;
// console.log(subects);
// console.log(subects1);

// function subects() {
//     console.log(`about ${this.name}!`);
//     }
//     const subects1 = { name: 'Math' };
//     subects.call(subects1);

function creatNames(surname) {
    return function(names) {
    return( names + surname);
    };
    }
    const ismlar = creatNames("Madina"); // 5% tax
  
    console.log(ismlar(`Yo'ldosheva `));
    

// Funksiya qaytaradigan va/yoki argument sifatida boshqa funksiya qabul
// qiladigan funksiyalarga HOF deyiladi

// Destructuring-arraydagi qiymat,obyektdagi xossani ajratish
// Rest operator - miqdori oldindan aniq bo’lmagan qiymatlarni array ko’rinishda ifodalash
// Spread operator - takrorlanadigan (array’ga o’xshash) qiymatlarni yoyish

// || (OR)-1-trueni and-2-trueni qaytaradi
// Nullish coalescing ( ?? ) -ifodaning chap operandi null yoki undefined bo’lgan holatda, o’ng
// tarafdagi qiymat qaytirilinadi, aks holda chap operand qiymatni qaytaradi

// const myMap = new Map();
// myMap.set('firstname', 'Ulugbek');
// myMap.set('lastname', 'Samigjonov');
// myMap.set('age', 25);

// const mySet = new Set();
// mySet.add(10); // Set(1) { 10 }
// mySet.add(15); // Set(2) { 10, 15 }
// mySet.add(15); // Set(2) { 10, 15 }
// mySet.add('Ulugbek'); // Set(3) { 1, 5, 'Ulugbek' }
// const person = { age: 25, job: 'Software Engineer' };
// mySet.add(person);
// console.log(mySet);

//Javascript Runtime-barcha dastur va kutbxonalar
// JS Engine - kompyuter dasturi bo’lib, Javascript tilida yozilgan kodni
// interpret qilish

// Hoisting-1-ishga tushirib keyin funk e'lon qilish
// TDZ (Temporal Dead Zone) - o’zgaruvchini scope boshlanishi va e’lon qilingan
// joyigacha bo’lgan hududga aytiladi. O’zgaruvchini TDZ ichida ishlatish,
// ReferenceError’ga olib keladi

// Javascript dasturlash tilida 7 xil ko’rinishdagi primitive ma’lumot turlari
// mavjud va ular: string , number , bigint , boolean , undefined , symbol va 
// null .

//Assignment (=) -qiymat o'zlashtirish

// function printName() {
//     console.log(`Hello, ${this.name}!`);
//     }
//     const person1 = { name: 'Ulugbek' };
//     printName.call(person1);
    
// const person = {
//     name: 'Ulugbek',
//     printName: function() {
//     setTimeout(() => {
//     console.log(`Hello, ${this.name}!`);
//     }, 1000);
//     }
//     }
//     person.printName();

